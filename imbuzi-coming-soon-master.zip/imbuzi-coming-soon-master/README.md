# IMBUZI Coming Soon Website Template

The entire code for IMBUZI Coming Soon Website, Free to use

<div>
  <img width="600px" src="https://github.com/alisolanki/imbuzi-coming-soon/blob/master/Screenshot%202023-11-02%20at%204.53.01%20PM.png"/>
</div>
